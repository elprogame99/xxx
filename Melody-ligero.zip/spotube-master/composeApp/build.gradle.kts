/*
 * Copyright (C) 2026 Kingkor Roy Tirtho and Spotube Contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import gobley.gradle.GobleyHost
import gobley.gradle.Variant
import gobley.gradle.cargo.dsl.jvm
import dev.nucleusframework.desktop.application.dsl.NativeImageOptimization
import org.jetbrains.compose.reload.gradle.ComposeHotRun
import org.gradle.api.tasks.Copy
import org.spotube.gradle.GitCliffContextTask
import org.spotube.gradle.RenderPackagingTask

plugins {
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.composeMultiplatform)
    alias(libs.plugins.composeCompiler)
    alias(libs.plugins.composeHotReload)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.zipline.gradle.plugin)
    alias(libs.plugins.vlcjBundler)
    alias(libs.plugins.uniffi)
    alias(libs.plugins.cargo)
    alias(libs.plugins.mokkery)
    alias(libs.plugins.neucleusFramework)
    kotlin("plugin.atomicfu") version libs.versions.kotlin
}

val bundleId = "org.spotube.spotube"
val version = "6.0.0"
// Set to N to release <version>-beta.N (same app id, icons and name as stable); null for a plain stable release.
// Installer metadata (packageVersion) must stay numeric, so it keeps using plain `version`.
val betaNumber: Int? = null
// Betas share the stable desktop app id.
val buildNumber = 47
// Desktop icon channel. Use -Pnightly=true for the nightly icon.
val isNightly = providers.gradleProperty("nightly").map { it.toBoolean() }.getOrElse(false)
val desktopIconDir = if (isNightly) "icons/nightly" else "icons/stable"
// Nightlies are numbered by the CI run (-PbuildNumber=<run>, or GITHUB_RUN_NUMBER) so every build is traceable to its run.
val nightlyBuildNumber = providers.gradleProperty("buildNumber").orNull?.toIntOrNull()
    ?: System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
    ?: buildNumber
// Production = shipping artifacts (installers, distributables, native images). Size/speed
// optimizations that slow builds down (Rust release + LTO) only apply then, never to `run`/dev.
// Override with -Pproduction=true|false.
val isProductionBuild = providers.gradleProperty("production").map { it.toBoolean() }.getOrElse(
    gradle.startParameter.taskNames.any { task ->
        task.substringAfterLast(':').let { name ->
            name.startsWith("package") || name.startsWith("create") ||
                name.startsWith("notarize") || name == "nativeImageCompile"
        }
    }
)
val targetName = "Melody"
val homePageUrl = "https://spotube.cc"
val repositoryUrl = "https://github.com/team-spotube/spotube"
val appVersionName = if (betaNumber != null) "$version-beta.$betaNumber" else version
val appBuildNumber = if (isNightly) nightlyBuildNumber else buildNumber
val appRepositoryUrl = repositoryUrl
// CI reads the release version from here instead of scraping this file.
tasks.register("printVersion") {
    val appVersion = appVersionName
    doLast { println(appVersion) }
}

// Package manager manifests: packaging/<target> rendered into build/packaging/<target> with the version, the
// release assets' checksums (-PpackagingArtifactsDir=<dir>) and the git-cliff changelog. See RenderPackagingTask.
// -PpackagingVersion=<x.y.z> packages an already tagged release from a newer checkout (the publish workflow).
val packagingVersion = providers.gradleProperty("packagingVersion").getOrElse(appVersionName)
val gitCliffContext = tasks.register<GitCliffContextTask>("gitCliffContext") {
    configFile.set(rootProject.layout.projectDirectory.file("cliff.toml"))
    repositoryDir.set(rootProject.layout.projectDirectory)
    // Nightlies are not a release: their commits stay unreleased
    if (!isNightly) tag.set("v$packagingVersion")
    outputFile.set(layout.buildDirectory.file("packaging/changelog-context.json"))
}
val packagingRootDir = rootProject.layout.projectDirectory
val packagingArtifactsDir = packagingRootDir.dir(providers.gradleProperty("packagingArtifactsDir"))
listOf("winget", "chocolatey").forEach { target ->
    tasks.register<RenderPackagingTask>("renderPackaging${target.replaceFirstChar { it.uppercase() }}") {
        description = "Renders packaging/$target into build/packaging/$target."
        templateDir.set(packagingRootDir.dir("packaging/$target"))
        version.set(packagingVersion)
        pkgrel.set(providers.gradleProperty("pkgrel").orElse("1"))
        repositoryUrl.set(appRepositoryUrl)
        artifactNames.set(
            mapOf(
                "windowsX64" to "Spotube-windows-x86_64-setup.exe",
            )
        )
        artifactsDir.set(packagingArtifactsDir)
        changelogContext.set(gitCliffContext.flatMap { it.outputFile })
        outputDir.set(layout.buildDirectory.dir("packaging/$target"))
    }
}
val githubRepositoryPath = repositoryUrl.removePrefix("https://github.com/")
// Full list (not releases/latest) so pre-release installs can be offered newer pre-releases.
val releasesApiUrl = "https://api.github.com/repos/$githubRepositoryPath/releases?per_page=50"
val generatedAppInfoDir = layout.buildDirectory.dir("generated/appBuildInfo/commonMain/kotlin")
val generateAppBuildInfo by tasks.registering(Copy::class) {
    description = "Generate AppBuildInfo.kt"
    from(layout.projectDirectory.file("src/commonMain/templates/AppBuildInfo.kt.template"))
    into(layout.buildDirectory.dir("generated/appBuildInfo/commonMain/kotlin/org/spotube/spotube"))
    rename("AppBuildInfo.kt.template", "AppBuildInfo.kt")
    expand(
        mapOf(
            "appVersion" to appVersionName,
            "appBuildNumber" to appBuildNumber,
            "repositoryUrl" to appRepositoryUrl,
            "releasesApiUrl" to releasesApiUrl,
        )
    )
    inputs.properties(
        mapOf(
            "appVersion" to appVersionName,
            "appBuildNumber" to appBuildNumber,
            "repositoryUrl" to appRepositoryUrl,
            "releasesApiUrl" to releasesApiUrl,
        )
    )
}

tasks.configureEach {
    if (name.startsWith("compile") && name.contains("Kotlin")) {
        dependsOn(generateAppBuildInfo)
    }
}

// This project is intentionally Windows-only. Bundle the VLC runtime with the Windows app.
vlcjBundler {
    packageName = "$bundleId.core.generated"
    objectName = "VLCBundleLoaderGenerated"
    bundleVlc = true
}


kotlin {
    jvm()
    jvmToolchain(21)

    sourceSets {
        val commonMain by getting {
            kotlin.srcDir(generatedAppInfoDir)
            dependencies {
                implementation(project(":plugin_interfaces"))
                implementation(libs.compose.runtime)
                implementation(libs.compose.foundation)
                implementation(libs.compose.ui)
                implementation(libs.coil.compose)
                implementation(libs.coil.network.ktor3)
                implementation(libs.compose.components.resources)
                implementation(libs.compose.uiToolingPreview)
                implementation(libs.androidx.lifecycle.viewmodelCompose)
                implementation(libs.androidx.lifecycle.runtimeCompose)
                implementation(libs.kotlinx.serialization.json)
                implementation(libs.kotlinx.coroutines.core)
                implementation(libs.kotlinx.datetime)
                implementation(libs.dns.sd.kt)
                implementation(libs.millennium)
                implementation(libs.jetbrains.navigation3.ui)
                implementation(libs.jetbrains.lifecycle.viewmodelNavigation3)
                api(libs.koin.core)
                implementation(libs.koin.compose)
                implementation(libs.koin.compose.viewmodel)
                implementation(libs.koin.compose.navigation3)
                implementation(libs.ktor.client.core)
                implementation(libs.ktor.client.logging)
                implementation(libs.ktor.client.content.negotiation)
                implementation(libs.ktor.client.serialization.kotlinx.json)
                implementation(libs.ktor.client.websockets)
                implementation(libs.ktor.server.core)
                implementation(libs.ktor.server.cio)
                implementation(libs.ktor.server.websockets)
                api(libs.zipline.core)
                implementation(libs.zipline.loader)
                implementation(libs.filekit.core)
                implementation(libs.filekit.dialogs)
                implementation(libs.filekit.dialogs.compose)
                implementation(libs.feather.icons)
                implementation(libs.androidx.datastore)
                implementation(libs.androidx.datastore.preferences)
                implementation(libs.kmp.zip)
                implementation(libs.kmp.zip.okio)
                implementation(libs.kmp.zip.kotlinx)
                implementation(libs.murmurhash)
                implementation(libs.kermit)
                implementation(libs.kermit.koin)
                implementation(libs.semver)
                implementation(libs.cryptography.core)
                implementation(libs.cryptography.provider.optimal)
                implementation(libs.compose.webview)
                implementation(libs.haze)
                implementation(libs.haze.blur)
                implementation(libs.haze.materials)
                implementation(libs.cache4k)
                implementation(libs.reorderable)
                implementation(libs.compose.shimmer)
                implementation(libs.multiplatform.markdown.renderer)
                implementation(libs.multiplatform.markdown.renderer.m3)
            }
        }
        commonTest.dependencies {
            implementation(libs.kotlin.test)
            implementation(libs.kotlinx.coroutines.test)
        }
        // JVM-only implementation shared by the desktop application.
        val desktopMain by creating {
            dependsOn(commonMain)
            dependencies {
                implementation(libs.newpipeextractor)
                implementation(libs.ktor.client.okhttp)
            }
        }
        jvmMain {
            dependsOn(desktopMain)
            dependencies {
                implementation(compose.desktop.currentOs)
                implementation(libs.kotlinx.coroutinesSwing)
                implementation(libs.vlcj)
                implementation(libs.vlcj.natives)
                implementation(libs.appdirs)
                implementation(libs.jna)
                implementation(libs.nucleus.core.runtime)
                implementation(libs.nucleus.graalvm.runtime)
                implementation(libs.nucleus.nucleus.application)
                implementation(libs.nucleus.decorated.window.tao)
                implementation(libs.compose.native.tray)
                implementation(libs.nucleus.media.control)
                implementation(libs.nucleus.darkmode.detector)
            }
        }
    }
}

dependencies {
    debugImplementation(libs.compose.uiTooling)
}

nucleus.application {
    mainClass = "org.spotube.spotube.MainKt"

    jvmArgs += listOf(
        "--enable-native-access=ALL-UNNAMED", // need for JNA for compose-webview (wry) to work
        // --- ADD THESE FOR SPEED & LOW RAM ---
        "-Xms64m",                  // Start with a tiny heap (prevents grabbing 500MB upfront)
        "-Xmx1g",                   // Ceiling, not a reservation: the heap only grows to what is live (#3200, #3193)
        "-XX:TieredStopAtLevel=1",  // Disables the heavy C2 compiler. Huge startup speedup!
        "-XX:+UseSerialGC"          // The Serial GC is the most efficient for heaps under 512MB
    )

    nativeDistributions {
        packageName = bundleId
        // User-facing name (.app bundle, DMG productName, Launchpad/Dock); packageName above is the reverse-DNS id.
        appName = if (isNightly) "Melody Nightly" else "Melody"
        packageVersion = version
        licenseFile = project.file("../LICENSE")

        appResourcesRootDir.set(vlcjBundler.vlcNativesDirectory)

        targetFormats(
            dev.nucleusframework.desktop.application.dsl.TargetFormat.Msi,
            dev.nucleusframework.desktop.application.dsl.TargetFormat.Exe,
        )

        modules("jdk.unsupported")

        homepage = homePageUrl

        windows {
            iconFile.set(project.file("$desktopIconDir/icon.ico"))
            shortcut = true
            menu = true
            dirChooser = true
            perUserInstall = true
        }


    }

    buildTypes.release.proguard {
        configurationFiles.from(project.file("proguard-rules.pro"))
    }

    // AOT-compiled native binary (no bundled JVM). Build with `packageGraalvmNative`, try it with
    // `runGraalvmNative`. Nucleus downloads GraalVM CE on first use (or uses $GRAALVM_HOME).
    // Reflection/JNI metadata the automatic passes miss (vlcj, Zipline, NewPipe/Rhino, uniffi)
    // lives in `graalvm/` and is (re)collected by exercising the app under `runWithNativeAgent`.
    graalvm {
        isEnabled = true
        imageName = "spotube"
        nativeImageConfigBaseDir.set(project.layout.projectDirectory.dir("graalvm"))
        // ProGuard is not used for native images; -Os is the size equivalent
        optimization = NativeImageOptimization.SIZE
        // Same ceiling as the JVM distribution's -Xmx
        maxHeapSize = "1g"
        // Skiko is loaded from lib/ next to the binary (Nucleus copies it there); don't embed
        // a second ~30 MB copy as a resource
        buildArgs.add("-H:+UnlockExperimentalVMOptions")
        buildArgs.add("-H:ExcludeResources=.*skiko-[^/]*\\.(so|dylib|dll)")
    }
}

// The uber JAR is what the GraalVM build compiles from, and native-image embeds every registered
// resource in the binary. Libraries ship natives for every OS/CPU, so keep only the host's
// (the uber JAR is per-OS/arch already; it isn't used by `run`).
tasks.withType<org.gradle.jvm.tasks.Jar>().matching { it.name.endsWith("UberJarForCurrentOS") }.configureEach {
    // Everything the exclude closure uses is local: the configuration cache can't serialize
    // references to the build script object.
    val foreignExtensions = setOf("so", "dylib", "jnilib", "a")
    val nativeExtensions = setOf("so", "dll", "dylib", "jnilib", "a")
    // CPU names as libraries spell them in their native folders.
    val cpuDirToken = Regex(
        "(?:^|[-_])(x86[-_]64|amd64|x64|aarch64|arm64|armv6|armv7|armel|arm|x86|i[36]86|ppc64le|ppc64|ppc" +
            "|s390x|riscv64|loongarch64|mips64el|sparcv9|sparc)(?=$|[-_])"
    )
    val hostCpuTokens = when (System.getProperty("os.arch").lowercase()) {
        "aarch64", "arm64" -> setOf("aarch64", "arm64")
        else -> setOf("x86-64", "x86_64", "amd64", "x64")
    }
    // OS flavours we never ship desktop builds for (sqlite-jdbc and JNA bundle these)
    val foreignOsDirToken = Regex("android|musl|freebsd|openbsd|dragonflybsd|aix|sunos")
    exclude { element ->
        val segments = element.path.lowercase().split('/')
        val extension = segments.last().substringAfterLast('.', "")
        !element.isDirectory && extension in nativeExtensions && (
            extension in foreignExtensions ||
                segments.dropLast(1).any { dir ->
                    foreignOsDirToken.containsMatchIn(dir) ||
                        cpuDirToken.findAll(dir).any { it.groupValues[1] !in hostCpuTokens }
                }
            )
    }
    // Exclude stale CEF binaries not loaded by the Windows desktop build.
    exclude(
        "nucleus/native/*/libcef.*",
        "nucleus/native/*/libcompose_cef_*",
        "nucleus/native/*/cef_subprocess*",
        "nucleus/native/*/*.pak",
        "nucleus/native/*/icudtl.dat",
        "nucleus/native/*/v8_context_snapshot.bin",
    )
}

// Issue with compose plugin
// https://github.com/JetBrains/compose-hot-reload/blob/master/docs/Known_limitations.md#property-composeapplicationresourcesdir-is-null-when-running-hot-reload-tasks
tasks.withType<ComposeHotRun>().configureEach {
    // Populates the resources dir below with the VLC natives (appResourcesRootDir); hot run doesn't depend on it by default
    dependsOn("prepareAppResources")
    jvmArgs(
        "--enable-native-access=ALL-UNNAMED"
    )
    systemProperty(
        "compose.application.resources.dir",
        project.layout.buildDirectory.dir("compose/tmp/prepareAppResources").get()
    )
}

cargo {
    // Gobley defaults desktop to the debug profile, which ships an unstripped ~31 MB library
    if (isProductionBuild) jvmVariant = Variant.Release
    builds.jvm {
        embedRustLibrary = (rustTarget == GobleyHost.current.rustTarget)
    }
}

