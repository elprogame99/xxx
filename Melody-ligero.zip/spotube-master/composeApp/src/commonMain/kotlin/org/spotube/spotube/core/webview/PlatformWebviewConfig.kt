/*
 * Copyright (C) 2026 Kingkor Roy Tirtho and Spotube Contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.spotube.spotube.core.webview

import dev.nucleusframework.webview.web.WebViewState

expect fun platformWebviewConfig(webView: WebViewState, pluginId: String?)

expect suspend fun platformClearWebviewData(pluginId: String?)

/**
 * Whether this platform's WebView cookie store returns cookies without their domain, and only
 * the ones it would send to the URL asked for. True on Android (`CookieManager.getCookie(url)`
 * gives a bare `name=value` header). Elsewhere every cookie carries its domain.
 */
expect val webViewCookiesWithoutDomainAreUrlScoped: Boolean
