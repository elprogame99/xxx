/*
 * Copyright (C) 2026 Kingkor Roy Tirtho and Spotube Contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.spotube.spotube.core.ui.theming

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.spotube.spotube.modules.settings.AppDesign

/**
 * Every colour a Melody design defines.
 *
 * The member names deliberately mirror the Millennium colour roles (`accent`, `raised`,
 * `border`, `muted`, ...) so call sites that used `MillenniumTheme.colors` read
 * `MelodyTheme.colors` instead and follow the selected [AppDesign]. The last group holds
 * the extra tokens (gradient background, card fill, gradient border, glow) that only the
 * Melody surfaces use.
 */
@Immutable
data class MelodyThemeColors(
    val accent: Color,
    val accentTop: Color,
    val accentBottom: Color,
    val onAccent: Color,
    val accentContainer: Color,
    val onAccentContainer: Color,
    val secondary: Color,
    val onSecondary: Color,
    val secondaryContainer: Color,
    val background: Color,
    val surface: Color,
    val raised: Color,
    val raisedHighest: Color,
    val inset: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val danger: Color,
    val success: Color,
    val highlight: Color,
    val scrim: Color,
    // Gradient background (Aurora) / near-flat background (Midnight).
    val backgroundStart: Color,
    val backgroundMiddle: Color,
    val backgroundEnd: Color,
    val backgroundGlowA: Color,
    val backgroundGlowB: Color,
    // Cards: fill gradient + border gradient + glow.
    val cardFillTop: Color,
    val cardFillBottom: Color,
    val borderStart: Color,
    val borderEnd: Color,
    val glow: Color
)

/** Linear interpolation of every token; drives the ~300 ms design-switch transition. */
internal fun lerpColors(a: MelodyThemeColors, b: MelodyThemeColors, t: Float): MelodyThemeColors =
    MelodyThemeColors(
        accent = lerp(a.accent, b.accent, t),
        accentTop = lerp(a.accentTop, b.accentTop, t),
        accentBottom = lerp(a.accentBottom, b.accentBottom, t),
        onAccent = lerp(a.onAccent, b.onAccent, t),
        accentContainer = lerp(a.accentContainer, b.accentContainer, t),
        onAccentContainer = lerp(a.onAccentContainer, b.onAccentContainer, t),
        secondary = lerp(a.secondary, b.secondary, t),
        onSecondary = lerp(a.onSecondary, b.onSecondary, t),
        secondaryContainer = lerp(a.secondaryContainer, b.secondaryContainer, t),
        background = lerp(a.background, b.background, t),
        surface = lerp(a.surface, b.surface, t),
        raised = lerp(a.raised, b.raised, t),
        raisedHighest = lerp(a.raisedHighest, b.raisedHighest, t),
        inset = lerp(a.inset, b.inset, t),
        border = lerp(a.border, b.border, t),
        text = lerp(a.text, b.text, t),
        muted = lerp(a.muted, b.muted, t),
        danger = lerp(a.danger, b.danger, t),
        success = lerp(a.success, b.success, t),
        highlight = lerp(a.highlight, b.highlight, t),
        scrim = lerp(a.scrim, b.scrim, t),
        backgroundStart = lerp(a.backgroundStart, b.backgroundStart, t),
        backgroundMiddle = lerp(a.backgroundMiddle, b.backgroundMiddle, t),
        backgroundEnd = lerp(a.backgroundEnd, b.backgroundEnd, t),
        backgroundGlowA = lerp(a.backgroundGlowA, b.backgroundGlowA, t),
        backgroundGlowB = lerp(a.backgroundGlowB, b.backgroundGlowB, t),
        cardFillTop = lerp(a.cardFillTop, b.cardFillTop, t),
        cardFillBottom = lerp(a.cardFillBottom, b.cardFillBottom, t),
        borderStart = lerp(a.borderStart, b.borderStart, t),
        borderEnd = lerp(a.borderEnd, b.borderEnd, t),
        glow = lerp(a.glow, b.glow, t)
    )

/** Maps a design's colours onto the app's semantic role names used by `AppTheme.colors`. */
fun appColorsFrom(m: MelodyThemeColors): AppColors = AppColors(
    primary = m.accent,
    onPrimary = m.onAccent,
    primaryContainer = m.accentContainer,
    onPrimaryContainer = m.onAccentContainer,
    secondary = m.secondary,
    onSecondary = m.onSecondary,
    secondaryContainer = m.secondaryContainer,
    onSecondaryContainer = m.text,
    tertiaryContainer = m.raised,
    onTertiaryContainer = m.text,
    background = m.background,
    onBackground = m.text,
    surface = m.surface,
    onSurface = m.text,
    surfaceVariant = m.inset,
    onSurfaceVariant = m.muted,
    surfaceContainer = m.surface,
    surfaceContainerHigh = m.raised,
    surfaceContainerHighest = m.raisedHighest,
    inverseSurface = m.text,
    inverseOnSurface = m.background,
    outline = m.border,
    outlineVariant = m.border,
    error = m.danger,
    onError = m.background,
    errorContainer = m.danger.copy(alpha = 0.16f),
    onErrorContainer = m.danger,
    scrim = m.scrim
)

/**
 * Everything that makes a design look like itself: colours, corner shapes, type weights and
 * the surface behaviour (gradient borders, glow, corner scale for hard-coded shapes).
 */
@Immutable
data class MelodyTokens(
    val design: AppDesign,
    val colors: MelodyThemeColors,
    val shapes: AppShapes,
    val typography: AppTypography,
    /** Multiplier applied to every corner radius drawn through [melodySurface]. */
    val radiusScale: Float,
    /** Aurora: luminous gradient borders and coloured glow instead of plain shadows. */
    val luminous: Boolean
)

// ---------------------------------------------------------------------------------------------
// Midnight: carbon blacks, electric blue, crisp compact corners, thin borders, high contrast.
// ---------------------------------------------------------------------------------------------

private val MidnightColors = MelodyThemeColors(
    accent = Color(0xFF2979FF),
    accentTop = Color(0xFF4C94FF),
    accentBottom = Color(0xFF1F63E6),
    onAccent = Color(0xFFFFFFFF),
    accentContainer = Color(0xFF14264A),
    onAccentContainer = Color(0xFFD2E2FF),
    secondary = Color(0xFF6FA2FF),
    onSecondary = Color(0xFF06142E),
    secondaryContainer = Color(0xFF1A1B1F),
    background = Color(0xFF0A0A0C),
    surface = Color(0xFF121316),
    raised = Color(0xFF16171A),
    raisedHighest = Color(0xFF1F2024),
    inset = Color(0xFF0E0F11),
    border = Color(0xFF2A2C31),
    text = Color(0xFFF2F4F7),
    muted = Color(0xFF8D929B),
    danger = Color(0xFFFF5C6C),
    success = Color(0xFF35D07F),
    highlight = Color(0xFFFFFFFF),
    scrim = Color(0x99000000),
    backgroundStart = Color(0xFF0A0A0C),
    backgroundMiddle = Color(0xFF0B0B0E),
    backgroundEnd = Color(0xFF0F1013),
    backgroundGlowA = Color.Transparent,
    backgroundGlowB = Color.Transparent,
    cardFillTop = Color(0xFF16171A),
    cardFillBottom = Color(0xFF121316),
    borderStart = Color(0xFF2A2C31),
    borderEnd = Color(0xFF2A2C31),
    glow = Color(0x66000000)
)

// ---------------------------------------------------------------------------------------------
// Aurora: indigo/violet gradients, violet-blue-cyan accents, translucent luminous cards.
// ---------------------------------------------------------------------------------------------

private val AuroraColors = MelodyThemeColors(
    accent = Color(0xFF8B5CF6),
    accentTop = Color(0xFFA78BFA),
    accentBottom = Color(0xFF6D3FE0),
    onAccent = Color(0xFFFFFFFF),
    accentContainer = Color(0xFF3B2A7A),
    onAccentContainer = Color(0xFFEDE9FE),
    secondary = Color(0xFF22D3EE),
    onSecondary = Color(0xFF042A33),
    secondaryContainer = Color(0xFF123A55),
    background = Color(0xFF0D0A24),
    surface = Color(0xFF17123A),
    raised = Color(0xFF211A4D),
    raisedHighest = Color(0xFF2B2260),
    inset = Color(0xFF0A0820),
    border = Color(0xFF3B3270),
    text = Color(0xFFF5F3FF),
    muted = Color(0xFFA9A1D6),
    danger = Color(0xFFFB7185),
    success = Color(0xFF34D399),
    highlight = Color(0xFFC4B5FD),
    scrim = Color(0xB3060416),
    backgroundStart = Color(0xFF0B0820),
    backgroundMiddle = Color(0xFF160C36),
    backgroundEnd = Color(0xFF071425),
    backgroundGlowA = Color(0x4D8B5CF6),
    backgroundGlowB = Color(0x2E22D3EE),
    cardFillTop = Color(0x99281F66),
    cardFillBottom = Color(0x80140F38),
    borderStart = Color(0x8C8B5CF6),
    borderEnd = Color(0x6622D3EE),
    glow = Color(0x668B5CF6)
)

private fun textStyle(
    size: Int,
    lineHeight: Int,
    weight: FontWeight,
    letterSpacing: Float = 0f
): TextStyle = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontSize = size.sp,
    lineHeight = lineHeight.sp,
    fontWeight = weight,
    letterSpacing = letterSpacing.sp
)

private val MidnightTypography = AppTypography(
    displaySmall = textStyle(36, 44, FontWeight.SemiBold, -0.4f),
    headlineLarge = textStyle(32, 40, FontWeight.SemiBold, -0.3f),
    headlineMedium = textStyle(28, 36, FontWeight.SemiBold, -0.2f),
    headlineSmall = textStyle(24, 32, FontWeight.SemiBold, -0.2f),
    titleLarge = textStyle(22, 28, FontWeight.SemiBold, -0.1f),
    titleMedium = textStyle(16, 24, FontWeight.Medium),
    titleSmall = textStyle(14, 20, FontWeight.Medium),
    bodyLarge = textStyle(16, 24, FontWeight.Normal),
    bodyMedium = textStyle(14, 20, FontWeight.Normal),
    bodySmall = textStyle(12, 16, FontWeight.Normal),
    labelLarge = textStyle(14, 20, FontWeight.Medium),
    labelMedium = textStyle(12, 16, FontWeight.Medium),
    labelSmall = textStyle(11, 16, FontWeight.Medium)
)

private val AuroraTypography = AppTypography(
    displaySmall = textStyle(38, 46, FontWeight.ExtraBold, -0.6f),
    headlineLarge = textStyle(33, 42, FontWeight.Bold, -0.5f),
    headlineMedium = textStyle(29, 38, FontWeight.Bold, -0.4f),
    headlineSmall = textStyle(25, 34, FontWeight.Bold, -0.3f),
    titleLarge = textStyle(23, 30, FontWeight.Bold, -0.2f),
    titleMedium = textStyle(16, 25, FontWeight.SemiBold, 0.1f),
    titleSmall = textStyle(14, 21, FontWeight.SemiBold, 0.1f),
    bodyLarge = textStyle(16, 26, FontWeight.Normal, 0.1f),
    bodyMedium = textStyle(14, 22, FontWeight.Normal, 0.1f),
    bodySmall = textStyle(12, 18, FontWeight.Normal, 0.15f),
    labelLarge = textStyle(14, 20, FontWeight.SemiBold, 0.3f),
    labelMedium = textStyle(12, 16, FontWeight.SemiBold, 0.4f),
    labelSmall = textStyle(11, 16, FontWeight.SemiBold, 0.4f)
)

private val MidnightShapes = AppShapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(10.dp)
)

private val AuroraShapes = AppShapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp)
)

private val MidnightTokens = MelodyTokens(
    design = AppDesign.MIDNIGHT,
    colors = MidnightColors,
    shapes = MidnightShapes,
    typography = MidnightTypography,
    radiusScale = 0.75f,
    luminous = false
)

private val AuroraTokens = MelodyTokens(
    design = AppDesign.AURORA,
    colors = AuroraColors,
    shapes = AuroraShapes,
    typography = AuroraTypography,
    radiusScale = 1.7f,
    luminous = true
)

/** The static token set of a design (also used to draw previews of a design that is not active). */
fun melodyTokens(design: AppDesign): MelodyTokens = when (design) {
    AppDesign.MIDNIGHT -> MidnightTokens
    AppDesign.AURORA -> AuroraTokens
}

val LocalMelodyTokens = compositionLocalOf { MidnightTokens }

/** Reads the active Melody design. Replaces direct `MillenniumTheme.colors` reads in the app. */
object MelodyTheme {
    val tokens: MelodyTokens @Composable get() = LocalMelodyTokens.current
    val colors: MelodyThemeColors @Composable get() = LocalMelodyTokens.current.colors
    val design: AppDesign @Composable get() = LocalMelodyTokens.current.design
}

/**
 * Cross-fades colours between designs over ~300 ms so switching never flashes. Shapes and type
 * switch at the start of the transition; only colours are interpolated.
 */
@Composable
fun animateMelodyTokens(target: MelodyTokens): MelodyTokens {
    var from by remember { mutableStateOf(target.colors) }
    var to by remember { mutableStateOf(target.colors) }
    val progress = remember { Animatable(1f) }

    LaunchedEffect(target.colors) {
        if (target.colors != to) {
            from = lerpColors(from, to, progress.value)
            to = target.colors
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = 300))
        }
    }

    val colors = if (progress.value >= 1f) to else lerpColors(from, to, progress.value)
    return target.copy(colors = colors)
}

// ---------------------------------------------------------------------------------------------
// Surfaces, brushes, backgrounds.
// ---------------------------------------------------------------------------------------------

/** Scales a corner-based shape's radii so hard-coded `RoundedCornerShape(12.dp)` follows the design. */
private class ScaledCornerSize(private val base: CornerSize, private val scale: Float) : CornerSize {
    override fun toPx(shapeSize: androidx.compose.ui.geometry.Size, density: Density): Float =
        base.toPx(shapeSize, density) * scale
}

internal fun Shape.melodyScaled(scale: Float): Shape {
    if (scale == 1f || this == CircleShape || this !is CornerBasedShape) return this
    return copy(
        topStart = ScaledCornerSize(topStart, scale),
        topEnd = ScaledCornerSize(topEnd, scale),
        bottomEnd = ScaledCornerSize(bottomEnd, scale),
        bottomStart = ScaledCornerSize(bottomStart, scale)
    )
}

/** Card fill: flat carbon in Midnight, translucent violet gradient in Aurora. */
fun melodyPanelBrush(colors: MelodyThemeColors): Brush =
    Brush.verticalGradient(listOf(colors.cardFillTop, colors.cardFillBottom))

/** Slightly lifted (or, with [sunken], recessed) fill for tiles, chips and skeletons. */
fun melodyBevelBrush(colors: MelodyThemeColors, sunken: Boolean = false): Brush =
    if (sunken) {
        Brush.verticalGradient(listOf(colors.inset, colors.surface))
    } else {
        Brush.verticalGradient(listOf(colors.raisedHighest, colors.raised))
    }

/** Accent wash for hovered/pressed/selected rows; [wash] is the opacity (0..1). */
fun melodySelectedBrush(colors: MelodyThemeColors, wash: Float): Brush =
    Brush.verticalGradient(
        listOf(
            colors.accentTop.copy(alpha = wash.coerceIn(0f, 1f)),
            colors.accentBottom.copy(alpha = wash.coerceIn(0f, 1f))
        )
    )

/** Full-screen background brush of the design (diagonal three-stop gradient). */
fun melodyBackgroundBrush(colors: MelodyThemeColors): Brush = Brush.linearGradient(
    colors = listOf(colors.backgroundStart, colors.backgroundMiddle, colors.backgroundEnd)
)

/**
 * Paints the design's background: gradient plus, in Aurora, two soft radial glows. Used for the
 * app shell, the lyrics overlay and any other full-bleed backdrop.
 */
@Composable
fun Modifier.melodyBackground(): Modifier {
    val colors = MelodyTheme.colors
    return this
        .background(melodyBackgroundBrush(colors))
        .drawBehind {
            if (colors.backgroundGlowA.alpha > 0.001f) {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(colors.backgroundGlowA, Color.Transparent),
                        center = Offset(size.width * 0.12f, size.height * 0.02f),
                        radius = size.maxDimension * 0.65f
                    )
                )
            }
            if (colors.backgroundGlowB.alpha > 0.001f) {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(colors.backgroundGlowB, Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.98f),
                        radius = size.maxDimension * 0.6f
                    )
                )
            }
        }
}

/**
 * Melody's card/surface modifier (replaces Millennium's `millenniumSurface`; same parameter
 * names so call sites only change the function name).
 *
 * - Corners follow the design (compact in Midnight, very round in Aurora).
 * - Midnight: flat fill, thin solid border, discreet shadow.
 * - Aurora: translucent fill, gradient border, coloured glow instead of a grey shadow.
 */
fun Modifier.melodySurface(
    background: Brush,
    shape: Shape,
    borderColor: Color = Color.Unspecified,
    borderWidth: Dp = 0.dp,
    shadowElevation: Dp = 0.dp,
    innerGlowColor: Color = Color.Unspecified
): Modifier = composed {
    val tokens = MelodyTheme.tokens
    val colors = tokens.colors
    val finalShape = shape.melodyScaled(tokens.radiusScale)

    var result: Modifier = Modifier
    if (shadowElevation > 0.dp) {
        result = if (tokens.luminous) {
            result.shadow(
                elevation = shadowElevation.coerceAtLeast(6.dp),
                shape = finalShape,
                clip = false,
                ambientColor = colors.glow,
                spotColor = colors.glow
            )
        } else {
            result.shadow(elevation = shadowElevation, shape = finalShape, clip = false)
        }
    }
    result = result.background(background, finalShape)
    if (tokens.luminous && innerGlowColor != Color.Unspecified) {
        result = result.drawBehind {
            drawRect(
                Brush.verticalGradient(
                    listOf(innerGlowColor.copy(alpha = innerGlowColor.alpha * 0.18f), Color.Transparent),
                    endY = size.height * 0.5f
                )
            )
        }
    }
    if (borderWidth > 0.dp && borderColor != Color.Unspecified) {
        val borderBrush: Brush =
            if (tokens.luminous && borderColor == colors.border) {
                Brush.linearGradient(listOf(colors.borderStart, colors.borderEnd))
            } else {
                SolidColor(borderColor)
            }
        result = result.border(borderWidth, borderBrush, finalShape)
    }
    this.then(result)
}
