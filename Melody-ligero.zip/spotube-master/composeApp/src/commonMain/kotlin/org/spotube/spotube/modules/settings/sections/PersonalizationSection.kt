/*
 * Copyright (C) 2026 Kingkor Roy Tirtho and Spotube Contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package org.spotube.spotube.modules.settings.sections

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.composeunstyled.Text
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource
import org.spotube.millennium.composables.MillenniumButton
import org.spotube.millennium.composables.MillenniumIcon
import org.spotube.millennium.composables.MillenniumText
import org.spotube.spotube.core.ui.theming.AppTheme
import org.spotube.spotube.core.ui.theming.MelodyTheme
import org.spotube.spotube.core.ui.theming.MelodyTokens
import org.spotube.spotube.core.ui.theming.melodyBackgroundBrush
import org.spotube.spotube.core.ui.theming.melodyPanelBrush
import org.spotube.spotube.core.ui.theming.melodySurface
import org.spotube.spotube.core.ui.theming.melodyTokens
import org.spotube.spotube.modules.settings.AppDesign
import org.spotube.spotube.modules.settings.SettingsViewModel
import org.spotube.spotube.modules.settings.UserSettings
import org.spotube.spotube.resources.iconsax.Iconsax
import org.spotube.spotube.resources.iconsax.IconsaxCheckCircle
import spotube.composeapp.generated.resources.Res
import spotube.composeapp.generated.resources.settings_personalization_apply
import spotube.composeapp.generated.resources.settings_personalization_aurora_description
import spotube.composeapp.generated.resources.settings_personalization_aurora_name
import spotube.composeapp.generated.resources.settings_personalization_description
import spotube.composeapp.generated.resources.settings_personalization_midnight_description
import spotube.composeapp.generated.resources.settings_personalization_midnight_name
import spotube.composeapp.generated.resources.settings_personalization_preview_description
import spotube.composeapp.generated.resources.settings_personalization_selected
import spotube.composeapp.generated.resources.settings_section_personalization

/** Width from which the two design cards sit side by side instead of stacked. */
private val SideBySideMinWidth = 640.dp

/**
 * Personalization: pick one of the two Melody designs. The choice is stored in
 * [UserSettings.design] through [SettingsViewModel.selectDesign], which makes the whole
 * app re-theme live and survive restarts.
 */
internal fun LazyListScope.personalizationSection(
    settings: UserSettings,
    settingsViewModel: SettingsViewModel,
    includeHeader: Boolean = true) {
    if (includeHeader) {
        settingsSectionHeader(Res.string.settings_section_personalization)
    }
    item {
        Text(
            text = stringResource(Res.string.settings_personalization_description),
            style = AppTheme.typography.bodyMedium,
            color = AppTheme.colors.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp))
    }
    item {
        DesignChooser(
            selected = settings.design,
            onApply = settingsViewModel::selectDesign)
    }
}

@Composable
private fun DesignChooser(
    selected: AppDesign,
    onApply: (AppDesign) -> Unit) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)) {
        if (maxWidth >= SideBySideMinWidth) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                AppDesign.entries.forEach { design ->
                    DesignCard(
                        design = design,
                        selected = design == selected,
                        onApply = { onApply(design) },
                        modifier = Modifier.weight(1f))
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                AppDesign.entries.forEach { design ->
                    DesignCard(
                        design = design,
                        selected = design == selected,
                        onApply = { onApply(design) },
                        modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

private fun AppDesign.nameRes(): StringResource = when (this) {
    AppDesign.MIDNIGHT -> Res.string.settings_personalization_midnight_name
    AppDesign.AURORA -> Res.string.settings_personalization_aurora_name
}

private fun AppDesign.descriptionRes(): StringResource = when (this) {
    AppDesign.MIDNIGHT -> Res.string.settings_personalization_midnight_description
    AppDesign.AURORA -> Res.string.settings_personalization_aurora_description
}

@Composable
private fun DesignCard(
    design: AppDesign,
    selected: Boolean,
    onApply: () -> Unit,
    modifier: Modifier = Modifier) {
    val name = stringResource(design.nameRes())
    Column(
        modifier = modifier
            .melodySurface(
                background = melodyPanelBrush(MelodyTheme.colors),
                shape = AppTheme.shapes.large,
                borderColor = if (selected) AppTheme.colors.primary else MelodyTheme.colors.border,
                borderWidth = if (selected) 2.dp else 1.dp,
                shadowElevation = 4.dp)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DesignPreview(
            design = design,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .semantics {
                    contentDescription = stringResource(
                        Res.string.settings_personalization_preview_description, name)
                })
        Text(
            text = name,
            style = AppTheme.typography.titleLarge,
            color = AppTheme.colors.onSurface)
        Text(
            text = stringResource(design.descriptionRes()),
            style = AppTheme.typography.bodyMedium,
            color = AppTheme.colors.onSurfaceVariant)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 40.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                MillenniumIcon(
                    imageVector = Iconsax.IconsaxCheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = AppTheme.colors.primary)
                Text(
                    text = stringResource(Res.string.settings_personalization_selected),
                    style = AppTheme.typography.labelLarge,
                    color = AppTheme.colors.primary,
                    modifier = Modifier.padding(start = 8.dp))
            } else {
                MillenniumButton(onClick = onApply) {
                    MillenniumText(stringResource(Res.string.settings_personalization_apply))
                }
            }
        }
    }
}

/**
 * A miniature of the app drawn in the colours, corner radii and surface style of [design]
 * (independent of the active theme): sidebar, cards, player bar and progress.
 */
@Composable
private fun DesignPreview(design: AppDesign, modifier: Modifier = Modifier) {
    val tokens = melodyTokens(design)
    Canvas(modifier = modifier.clip(RoundedCornerShape(12.dp))) {
        drawDesignPreview(tokens)
    }
}

private fun DrawScope.drawDesignPreview(t: MelodyTokens) {
    val c = t.colors
    val w = size.width
    val h = size.height
    fun dp(v: Float) = v * (w / 320f)
    val cardRadius = dp(8f * t.radiusScale * 1.2f)

    // Backdrop (+ Aurora glows)
    drawRect(melodyBackgroundBrush(c))
    if (c.backgroundGlowA.alpha > 0.001f) {
        drawRect(Brush.radialGradient(
            listOf(c.backgroundGlowA, Color.Transparent),
            center = Offset(w * 0.15f, 0f), radius = w * 0.7f))
    }
    if (c.backgroundGlowB.alpha > 0.001f) {
        drawRect(Brush.radialGradient(
            listOf(c.backgroundGlowB, Color.Transparent),
            center = Offset(w * 0.95f, h), radius = w * 0.6f))
    }

    // Sidebar with four items, the first one selected.
    val sidebarW = w * 0.2f
    drawRect(c.surface.copy(alpha = if (t.luminous) 0.55f else 1f), size = Size(sidebarW, h))
    drawRect(c.border.copy(alpha = 0.7f), topLeft = Offset(sidebarW, 0f), size = Size(dp(1f), h))
    for (i in 0 until 4) {
        val y = dp(14f) + i * dp(18f)
        val selected = i == 0
        drawRoundRect(
            color = if (selected) c.accentContainer else c.raised.copy(alpha = 0.6f),
            topLeft = Offset(dp(8f), y),
            size = Size(sidebarW - dp(16f), dp(11f)),
            cornerRadius = CornerRadius(cardRadius * 0.5f))
        if (selected) {
            drawRoundRect(
                color = c.accent,
                topLeft = Offset(dp(8f), y),
                size = Size(dp(3f), dp(11f)),
                cornerRadius = CornerRadius(dp(2f)))
        }
    }

    // Title bars
    val contentX = sidebarW + dp(14f)
    drawRoundRect(c.text, Offset(contentX, dp(14f)), Size(dp(86f), dp(8f)), CornerRadius(dp(4f)))
    drawRoundRect(c.muted.copy(alpha = 0.7f), Offset(contentX, dp(28f)), Size(dp(52f), dp(5f)), CornerRadius(dp(3f)))

    // Three cards
    val gap = dp(10f)
    val cardW = (w - contentX - dp(14f) - gap * 2) / 3f
    val cardH = h * 0.36f
    val cardTop = dp(44f)
    for (i in 0 until 3) {
        val x = contentX + i * (cardW + gap)
        if (t.luminous) {
            drawRoundRect(
                brush = Brush.radialGradient(
                    listOf(c.glow, Color.Transparent),
                    center = Offset(x + cardW / 2, cardTop + cardH / 2), radius = cardW * 0.95f),
                topLeft = Offset(x - dp(6f), cardTop - dp(6f)),
                size = Size(cardW + dp(12f), cardH + dp(12f)),
                cornerRadius = CornerRadius(cardRadius + dp(6f)))
        }
        drawRoundRect(
            brush = melodyPanelBrush(c),
            topLeft = Offset(x, cardTop), size = Size(cardW, cardH),
            cornerRadius = CornerRadius(cardRadius))
        drawRoundRect(
            brush = if (t.luminous) Brush.linearGradient(
                listOf(c.borderStart, c.borderEnd),
                start = Offset(x, cardTop), end = Offset(x + cardW, cardTop + cardH))
            else Brush.linearGradient(listOf(c.border, c.border)),
            topLeft = Offset(x, cardTop), size = Size(cardW, cardH),
            cornerRadius = CornerRadius(cardRadius), style = Stroke(width = dp(1f)))
        // cover art
        val pad = dp(6f)
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(if (i == 1) c.secondary else c.accentTop, c.accentBottom),
                start = Offset(x + pad, cardTop + pad),
                end = Offset(x + cardW - pad, cardTop + cardH * 0.6f)),
            topLeft = Offset(x + pad, cardTop + pad),
            size = Size(cardW - pad * 2, cardH * 0.52f),
            cornerRadius = CornerRadius(cardRadius * 0.6f))
        drawRoundRect(c.text, Offset(x + pad, cardTop + cardH * 0.70f), Size(cardW * 0.62f, dp(4f)), CornerRadius(dp(2f)))
        drawRoundRect(c.muted.copy(alpha = 0.7f), Offset(x + pad, cardTop + cardH * 0.84f), Size(cardW * 0.4f, dp(3f)), CornerRadius(dp(2f)))
    }

    // Player bar with progress
    val barH = h * 0.2f
    val barTop = h - barH - dp(8f)
    val barX = sidebarW + dp(10f)
    val barW = w - barX - dp(10f)
    if (t.luminous) {
        drawRoundRect(
            brush = Brush.radialGradient(listOf(c.glow, Color.Transparent),
                center = Offset(barX + barW / 2, barTop + barH / 2), radius = barW * 0.55f),
            topLeft = Offset(barX - dp(4f), barTop - dp(8f)),
            size = Size(barW + dp(8f), barH + dp(16f)),
            cornerRadius = CornerRadius(cardRadius + dp(6f)))
    }
    drawRoundRect(
        brush = melodyPanelBrush(c),
        topLeft = Offset(barX, barTop), size = Size(barW, barH),
        cornerRadius = CornerRadius(cardRadius))
    drawRoundRect(
        color = c.border, topLeft = Offset(barX, barTop), size = Size(barW, barH),
        cornerRadius = CornerRadius(cardRadius), style = Stroke(width = dp(1f)))
    val trackY = barTop + barH * 0.62f
    val trackX = barX + dp(34f)
    val trackW = barW - dp(46f)
    drawRoundRect(c.border, Offset(trackX, trackY), Size(trackW, dp(4f)), CornerRadius(dp(2f)))
    val progress = trackW * 0.58f
    drawRoundRect(
        brush = Brush.horizontalGradient(
            listOf(c.accent, if (t.luminous) c.secondary else c.accentTop),
            startX = trackX, endX = trackX + progress),
        topLeft = Offset(trackX, trackY), size = Size(progress, dp(4f)),
        cornerRadius = CornerRadius(dp(2f)))
    drawCircle(c.text, radius = dp(4.5f), center = Offset(trackX + progress, trackY + dp(2f)))
    // play button + title line
    drawCircle(c.accent, radius = dp(7f), center = Offset(barX + dp(16f), barTop + barH * 0.4f))
    drawRoundRect(c.text, Offset(trackX, barTop + barH * 0.22f), Size(dp(70f), dp(5f)), CornerRadius(dp(3f)))
}
